import pandas as pd
import mysql.connector

# 1. Read Excel file
df = pd.read_excel( "Students.xlsx")
df.columns = df.columns.str.strip()


# 2. Connect to MySQL
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="1234",
    database="CAS"
)

cursor = conn.cursor()

# 3. Insert data row by row
sql = """
INSERT IGNORE INTO students (roll_no, name, year, department,zprn)
VALUES (%s, %s, %s, %s,%s)
"""

for _, row in df.iterrows():
    cursor.execute(sql, (
        int(row['roll_no']),
        row['name'],
        row['year'],
        row['department'],
        str(row['zprn'])
    ))

# 4. Save changes
conn.commit()

print("✅ Excel data successfully inserted into students table")

cursor.close()
conn.close()
print(df.columns)
df = pd.read_excel("students.xlsx")
df.columns = df.columns.str.strip()
df = df.fillna('')





