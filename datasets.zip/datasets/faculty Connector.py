import pandas as pd
import mysql.connector

# 1. Read Excel file
df = pd.read_excel("faculty.xlsx")
df.columns = df.columns.str.strip()
df = df.fillna('')

print(df.columns)  # debug check

# 2. Connect to MySQL
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="1234",
    database="CAS"
)

cursor = conn.cursor()

# 3. Insert faculty data
sql = """
INSERT IGNORE INTO faculty
(faculty_name, email, department, subject, password)
VALUES (%s, %s, %s, %s, %s)
"""

for _, row in df.iterrows():
    cursor.execute(sql, (
        row['faculty_name'],
        row['email'],
        row['department'],
        row['subject'],
        row['password']
    ))

# 4. Commit & close
conn.commit()
cursor.close()
conn.close()

print("✅ Excel data successfully inserted into faculty table")
